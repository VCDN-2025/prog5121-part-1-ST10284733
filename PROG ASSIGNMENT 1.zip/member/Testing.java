package member;

public class Testing {
     //Registers the name and ID
     public static void main (String[] args)
     {

      String name  =JOptionPane.showInputDialog("Register name");
      String id = JOptionPane.showInputDialog("Register member ID");

Member member new Member(name, id);

      String registeredMember = member.enrollMember();
      JOptionPane.showMessageDialog(null, registeredMember);


      if (member.checkID() == true)
      {
      String logIn = JOptionPane.showInputDialog("Enter your member iD"); 
      String logInName = JOptionPane.howInputDialog("Enter your member iD");

      boolean isAccessSuccessful = member.accessMember(logIn, logInName);
      String accessStatus = member.accessStatus (isAccessSuccessful);
      JOptionPane.showMessageDialog(null, accessStatus);
     }

}
}