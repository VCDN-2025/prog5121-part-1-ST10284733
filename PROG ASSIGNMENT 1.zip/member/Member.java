package member;

public class Member {
   String memberName;
   String memberID;
   // String memberPhoneNum;

public Member (String memberID, String memberName)
{
   this.memberName = memberName;
   this.memberID = memberID;
   // this.memberPhoneNum = memberPhoneNum:
}

    Member(String name, String id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
//Member ID
public boolean checkID()
{
    String regex = "MBR \\d(3,5)s";
    boolean isMemberIDValid = memberID.matches (regex);

    return isMemberIDValid;

}

public String enrollMember()
{
  if (checkID() == true)
{
    return "member ID is valid " + memberName + " registered successfully ";

} else
{
    return "member ID not formatted correctly";
}

}
//Displays to enter the name and ID

    /**
     *
     * @param idInput
     * @param nameInput
     * @return
     */
public boolean accessMember (String idInput, String nameInput)
{
   boolean nameMatches = memberID.equals (nameInput);
   boolean idMatches = memberID.equals (nameInput);
   if (idMatches & nameMatches == true)
{

   return true;

}else
{
   return isMemberIDValid;
}

public String enrollMember()
{
   if (checkID() == true)
   {
      return " member ID is valid " + " registered successfully ";
   }else
   {
      return  " member ID not formatted correctly "; 
   }
}



public boolean accessMember (String idInput, String nameInput)
{   
   boolean nameMatches = memberID.equals (nameInput);
   boolean idMatches = memberID.equals (nameInput); 
   if (idMatches && nameMatches == true)
   {

    return true;
    }else
    {
     return false;
    }

}
// Displays if the login is a success
public String accessStatus (boolean loginSuccess)
{
   if (loginSuccess == true)
   {
     return "Access granted";
    }else
    {
     return "Access denied";
    }

}
}